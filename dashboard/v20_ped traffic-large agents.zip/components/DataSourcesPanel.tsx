
import React from 'react';
import { UploadedFiles, SimulationParams } from '../types';
import { FileUp, Check, Database, Users, Clock } from 'lucide-react';
import { Slider } from './ui/Slider';

interface DataSourcesPanelProps {
  uploadedFiles: UploadedFiles;
  onFileUpload: (key: keyof UploadedFiles, file: File) => void;
  params: SimulationParams;
  setParams: React.Dispatch<React.SetStateAction<SimulationParams>>;
}

const FileUploadCard: React.FC<{
  label: string;
  description: string;
  fileKey: keyof UploadedFiles;
  uploadedFiles: UploadedFiles;
  onUpload: (key: keyof UploadedFiles, file: File) => void;
}> = ({ label, description, fileKey, uploadedFiles, onUpload }) => {
  const isUploaded = !!uploadedFiles[fileKey];

  return (
    <div className="bg-slate-800 border border-slate-700 rounded-lg p-4 flex items-start justify-between">
      <div>
        <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
          {label}
          {isUploaded && <Check className="w-4 h-4 text-green-500" />}
        </h3>
        <p className="text-xs text-slate-400 mt-1">{description}</p>
        {isUploaded && <p className="text-[10px] text-green-400 mt-2">File loaded successfully</p>}
      </div>
      <label className={`cursor-pointer flex items-center gap-2 px-3 py-2 rounded-md text-xs font-bold transition-colors ${isUploaded ? 'bg-slate-700 text-slate-300' : 'bg-blue-600 hover:bg-blue-500 text-white shadow-lg'}`}>
        <FileUp className="w-4 h-4" />
        {isUploaded ? 'Replace' : 'Upload JSON'}
        <input 
          type="file" 
          accept=".geojson,.json" 
          className="hidden" 
          onChange={(e) => {
            if (e.target.files?.[0]) {
              onUpload(fileKey, e.target.files[0]);
            }
          }}
        />
      </label>
    </div>
  );
};

export const DataSourcesPanel: React.FC<DataSourcesPanelProps> = ({ uploadedFiles, onFileUpload, params, setParams }) => {
  
  const updatePedestrian = (key: keyof SimulationParams['pedestrian'], value: any) => {
    setParams(prev => ({
      ...prev,
      pedestrian: {
        ...prev.pedestrian,
        [key]: value
      }
    }));
  };

  const updateTime = (key: keyof SimulationParams['timeRanges'], value: number) => {
    setParams(prev => ({
        ...prev,
        timeRanges: {
            ...prev.timeRanges,
            [key]: value
        }
    }));
  };

  return (
    <div className="p-8 bg-slate-950 h-full overflow-y-auto">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-white flex items-center gap-3">
            <Database className="w-6 h-6 text-pink-500" />
            Data Sources
          </h2>
          <p className="text-slate-400 mt-2">Manage the GeoJSON datasets and base agent configurations for the simulation.</p>
        </div>

        {/* Agent Configuration Section */}
        <div className="mb-8 bg-slate-900 border border-slate-800 rounded-xl p-6">
           <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
             <Users className="w-5 h-5 text-blue-400" />
             Pedestrian Agent Configuration
           </h3>
           <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex flex-col gap-2">
                <label className="text-sm font-medium text-slate-400">Base Residents (per 100)</label>
                <div className="relative">
                  <input 
                    type="number" 
                    value={params.pedestrian.baseResidentCount}
                    onChange={(e) => updatePedestrian('baseResidentCount', parseInt(e.target.value) || 0)}
                    className="w-full bg-slate-800 border border-slate-700 text-yellow-400 font-mono text-lg rounded-lg px-4 py-3 focus:ring-2 focus:ring-yellow-500 focus:border-transparent transition-all"
                  />
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-600 font-bold uppercase">Agents</div>
                </div>
                <p className="text-xs text-slate-500">Number of agents spawned at Residential buildings in the baseline scenario.</p>
              </div>
              
              <div className="flex flex-col gap-2">
                <label className="text-sm font-medium text-slate-400">Base Commuters (per 100)</label>
                 <div className="relative">
                  <input 
                    type="number" 
                    value={params.pedestrian.baseCommuterCount}
                    onChange={(e) => updatePedestrian('baseCommuterCount', parseInt(e.target.value) || 0)}
                    className="w-full bg-slate-800 border border-slate-700 text-orange-400 font-mono text-lg rounded-lg px-4 py-3 focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all"
                  />
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-600 font-bold uppercase">Agents</div>
                </div>
                <p className="text-xs text-slate-500">Number of agents entering via Transit Stops/Stations in the baseline scenario.</p>
              </div>
           </div>
        </div>

         {/* Time Configuration Section */}
         <div className="mb-8 bg-slate-900 border border-slate-800 rounded-xl p-6">
           <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
             <Clock className="w-5 h-5 text-orange-400" />
             Simulation Time Configuration
           </h3>
           <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="p-3 bg-slate-800/50 rounded-lg">
                 <h4 className="text-xs font-bold text-slate-300 uppercase mb-1">Morning Peak</h4>
                 <p className="text-[10px] text-slate-500 mb-3">Earliest and latest hours to commute to work.</p>
                 <Slider label="Start Hour" value={params.timeRanges.morningStart} min={0} max={23} onChange={(v) => updateTime('morningStart', v)} />
                 <Slider label="End Hour" value={params.timeRanges.morningEnd} min={0} max={23} onChange={(v) => updateTime('morningEnd', v)} />
              </div>
              <div className="p-3 bg-slate-800/50 rounded-lg">
                 <h4 className="text-xs font-bold text-slate-300 uppercase mb-1">Off-Peak</h4>
                 <p className="text-[10px] text-slate-500 mb-3">Typical work hours.</p>
                 <Slider label="Start Hour" value={params.timeRanges.offpeakStart} min={0} max={23} onChange={(v) => updateTime('offpeakStart', v)} />
                 <Slider label="End Hour" value={params.timeRanges.offpeakEnd} min={0} max={23} onChange={(v) => updateTime('offpeakEnd', v)} />
              </div>
              <div className="p-3 bg-slate-800/50 rounded-lg">
                 <h4 className="text-xs font-bold text-slate-300 uppercase mb-1">Evening Peak</h4>
                 <p className="text-[10px] text-slate-500 mb-3">Earliest and latest hours to leave work.</p>
                 <Slider label="Start Hour" value={params.timeRanges.eveningStart} min={0} max={23} onChange={(v) => updateTime('eveningStart', v)} />
                 <Slider label="End Hour" value={params.timeRanges.eveningEnd} min={0} max={23} onChange={(v) => updateTime('eveningEnd', v)} />
              </div>
           </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-slate-300 border-b border-slate-800 pb-2">Infrastructure Layers</h3>
            <FileUploadCard 
              label="Buildings" 
              description="Polygon features with 'NATURE' property (R/Office)." 
              fileKey="buildings" 
              uploadedFiles={uploadedFiles} 
              onUpload={onFileUpload} 
            />
            <FileUploadCard 
              label="Road Network" 
              description="LineStrings representing the drivable road graph." 
              fileKey="roads" 
              uploadedFiles={uploadedFiles} 
              onUpload={onFileUpload} 
            />
             <FileUploadCard 
              label="Transit Stops" 
              description="Point features for standard transit stops." 
              fileKey="stops" 
              uploadedFiles={uploadedFiles} 
              onUpload={onFileUpload} 
            />
             <FileUploadCard 
              label="Cable Stations" 
              description="Point features for cable car stations." 
              fileKey="cableStations" 
              uploadedFiles={uploadedFiles} 
              onUpload={onFileUpload} 
            />
          </div>

          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-slate-300 border-b border-slate-800 pb-2">Transit Schedules (Segments)</h3>
            <FileUploadCard 
              label="Morning Peak" 
              description="Transit routes active during morning peak." 
              fileKey="morning" 
              uploadedFiles={uploadedFiles} 
              onUpload={onFileUpload} 
            />
            <FileUploadCard 
              label="Off-Peak" 
              description="Transit routes active during off-peak." 
              fileKey="offpeak" 
              uploadedFiles={uploadedFiles} 
              onUpload={onFileUpload} 
            />
            <FileUploadCard 
              label="Evening Peak" 
              description="Transit routes active during evening peak." 
              fileKey="evening" 
              uploadedFiles={uploadedFiles} 
              onUpload={onFileUpload} 
            />
          </div>
        </div>
      </div>
    </div>
  );
};
