import React from 'react';

interface SliderProps {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  unit?: string;
  onChange: (value: number) => void;
  colorClass?: string;
}

export const Slider: React.FC<SliderProps> = ({ 
  label, 
  value, 
  min, 
  max, 
  step = 1, 
  unit = '', 
  onChange,
  colorClass = 'accent-blue-500'
}) => {
  return (
    <div className="flex flex-col gap-2 mb-4">
      <div className="flex justify-between items-center text-xs font-medium text-slate-400 uppercase tracking-wider">
        <span>{label}</span>
        <span className="text-slate-100">{value}{unit}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className={`w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer ${colorClass}`}
      />
    </div>
  );
};