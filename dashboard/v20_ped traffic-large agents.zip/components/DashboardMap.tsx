
import React, { useEffect, useState, useMemo } from 'react';
import { MapContainer, TileLayer, GeoJSON, useMap } from 'react-leaflet';
import L from 'leaflet';
import { SimulationParams, GeoJSONCollection, UploadedFiles } from '../types';
import { AgentSimulationLayer } from './AgentSimulationLayer';

// Use CDN for icons
const DefaultIcon = L.icon({
    iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
    iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
    shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
    tooltipAnchor: [16, -28],
    shadowSize: [41, 41]
});

L.Marker.prototype.options.icon = DefaultIcon;

interface DashboardMapProps {
  params: SimulationParams;
  layerVisibility: Record<string, boolean>;
  uploadedFiles: UploadedFiles;
  simHour: number;
}

const MapFitter = ({ bounds }: { bounds: GeoJSONCollection | null }) => {
  const map = useMap();
  useEffect(() => {
    if (bounds && bounds.features && bounds.features.length > 0) {
      const geoJsonLayer = L.geoJSON(bounds as any);
      map.fitBounds(geoJsonLayer.getBounds());
    }
  }, [bounds, map]);
  return null;
};

export const DashboardMap: React.FC<DashboardMapProps> = ({ 
  params, 
  layerVisibility, 
  uploadedFiles,
  simHour,
}) => {
  const [data, setData] = useState<{
    bounds: GeoJSONCollection | null;
    buildings: GeoJSONCollection | null;
    roads: GeoJSONCollection | null;
    stops: GeoJSONCollection | null;
    cableStations: GeoJSONCollection | null;
    transitSegments: GeoJSONCollection | null;
  }>({
    bounds: null,
    buildings: null,
    roads: null,
    stops: null,
    cableStations: null,
    transitSegments: null,
  });

  const [loading, setLoading] = useState(true);

  // Load Data
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const load = async (path: string) => {
          try {
            const res = await fetch(path);
            if (!res.ok) throw new Error('Not found');
            return await res.json();
          } catch (e) {
            console.warn(`Could not load ${path}, returning empty collection`);
            return { type: 'FeatureCollection', features: [] };
          }
        };

        const [bounds, buildings, roads, stops, cable, morning, offpeak, evening] = await Promise.all([
          load('data/CBD_Bounds.geojson'),
          load('data/CBD_Buildings.geojson'),
          load('data/CBD_Roads.geojson'),
          load('data/CBD_stops.geojson'),
          load('data/CBD_Cable_Station.geojson'),
          load('data/Freetown_Morning.geojson'),
          load('data/Freetown_Off_Peak.geojson'),
          load('data/Freetown_Evening.geojson'),
        ]);

        let activeSegments = morning;
        if (params.timeOfDay === 'Off-peak') activeSegments = offpeak;
        if (params.timeOfDay === 'Evening') activeSegments = evening;

        setData({
          bounds,
          buildings,
          roads,
          stops,
          cableStations: cable,
          transitSegments: activeSegments
        });
      } catch (err) {
        console.error("Error loading GeoJSON data:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [params.timeOfDay]);

  // Merge Uploads
  const activeBuildings = uploadedFiles.buildings || data.buildings;
  const activeRoads = uploadedFiles.roads || data.roads;
  const activeStops = uploadedFiles.stops || data.stops;
  const activeCableStations = uploadedFiles.cableStations || data.cableStations;
  
  const activeTransitSegments = useMemo(() => {
    const timeKeyMap: Record<string, keyof UploadedFiles> = {
      'Morning': 'morning',
      'Off-peak': 'offpeak',
      'Evening': 'evening',
    };
    const key = timeKeyMap[params.timeOfDay];
    if (key && uploadedFiles[key]) return uploadedFiles[key];
    return data.transitSegments;
  }, [params.timeOfDay, uploadedFiles, data.transitSegments]);


  // Styles
  const buildingStyle = (feature: any) => {
    const nature = feature?.properties?.NATURE;
    let fillColor = "#444444";
    if (nature === "office" || nature === "Office") fillColor = "#3b82f6"; // blue
    if (nature === "R" || nature === "Residential") fillColor = "#cbd5e1"; // light grey for residential
    
    return {
      color: "#0f172a",
      weight: 0.5,
      fillColor: fillColor,
      fillOpacity: 0.6,
    };
  };

  const roadStyle = (feature: any) => {
    // Generate pseudorandom intensity for demonstration
    // Use coordinate sum to be deterministic per road segment
    const coords = feature.geometry.coordinates;
    const seed = (coords[0]?.[0] || 0) + (coords[0]?.[1] || 0);
    
    // Destruction Logic
    // If off-peak (Working hours), Green roads (No impact)
    const tr = params.timeRanges;
    const isOffPeak = simHour >= tr.offpeakStart && simHour < tr.offpeakEnd;
    
    if (isOffPeak) {
        return {
          color: "#22c55e", // Green
          weight: 2,
          opacity: 0.8
        };
    }

    // Commuting Hours: Responsive destruction
    // Impacted by total agents, reduced by cable car preference (load relief)
    const totalAgents = params.counts?.total || 1000;
    const relief = (params.cableCarTransitShare || 0) / 100; // 0 to 1
    
    // Higher agent count = higher base destruction
    // Higher cable share = lower destruction multiplier
    let destruction = (totalAgents / 3000) * (1 - (relief * 0.5));
    
    // Add some variation per road
    destruction += (Math.sin(seed * 1000) * 0.2);
    destruction = Math.max(0, Math.min(1, destruction));

    // Color Scale: Green (Low) -> Yellow -> Red (High)
    let color = "#22c55e";
    if (destruction > 0.4) color = "#eab308";
    if (destruction > 0.7) color = "#ef4444";

    return {
      color: color,
      weight: 2,
      opacity: 0.8
    };
  };

  const transitStyle = () => {
    return {
      color: '#d1d5db', // Light Grey
      weight: 3,
      opacity: 0.7,
      dashArray: '5, 5'
    };
  };

  const stopMarker = (feature: any, latlng: L.LatLng) => {
    return L.circleMarker(latlng, {
      radius: 4,
      color: "#ffffff",
      weight: 1,
      fillColor: "#f97316", // Orange for bus stops
      fillOpacity: 1,
    });
  };

  const cableMarker = (feature: any, latlng: L.LatLng) => {
    return L.circleMarker(latlng, {
      radius: 6,
      color: "#ffffff",
      weight: 2,
      fillColor: "#06b6d4", // Cyan
      fillOpacity: 1,
    });
  };

  if (loading && !activeBuildings) {
    return <div className="w-full h-full flex items-center justify-center bg-slate-900 text-slate-500">Loading geospatial data...</div>;
  }

  return (
    <div className="relative w-full h-full">
      <MapContainer 
        center={[8.484, -13.23]} 
        zoom={13} 
        style={{ height: '100%', width: '100%', background: '#0f172a' }}
        zoomControl={false}
      >
        <TileLayer
          attribution='&copy; CARTO'
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
        />
        
        {data.bounds && <MapFitter bounds={data.bounds} />}

        {layerVisibility.buildings && activeBuildings && (
          <GeoJSON data={activeBuildings as any} style={buildingStyle} />
        )}

        {layerVisibility.roads && activeRoads && (
          <GeoJSON key={`roads-${simHour}-${params.counts?.total}-${params.cableCarTransitShare}`} data={activeRoads as any} style={roadStyle} />
        )}

        {layerVisibility.transitSegments && activeTransitSegments && (
          <GeoJSON key={`transit-${params.timeOfDay}`} data={activeTransitSegments as any} style={transitStyle()} />
        )}

        {/* Dynamic Agent Animation Layer */}
        {layerVisibility.agents && (
            <AgentSimulationLayer 
                roads={activeRoads} 
                transit={activeTransitSegments} 
                buildings={activeBuildings}
                stops={activeStops}
                cableStations={activeCableStations}
                params={params} 
                simHour={simHour}
            />
        )}

        {layerVisibility.stops && activeStops && (
          <GeoJSON 
            data={activeStops as any} 
            pointToLayer={stopMarker} 
            onEachFeature={(feature, layer) => layer.bindPopup(`<b>Stop:</b> ${feature.properties.stop_name || 'N/A'}`)}
          />
        )}

        {layerVisibility.cableStations && activeCableStations && (
          <GeoJSON 
            data={activeCableStations as any} 
            pointToLayer={cableMarker}
            onEachFeature={(feature, layer) => layer.bindPopup(`<b>Cable Station:</b> ${feature.properties.stop_name || 'N/A'}`)}
          />
        )}
      </MapContainer>

      {/* Legend Overlay */}
      <div className="absolute top-4 left-4 bg-slate-900/90 backdrop-blur-sm p-4 rounded-lg border border-slate-700 shadow-xl z-[400] text-xs">
        <h4 className="font-bold mb-2 text-slate-300">Legend</h4>
        <div className="space-y-1.5">
          <div className="flex items-center gap-2"><span className="w-3 h-3 rounded-sm bg-blue-500"></span> Office Buildings</div>
          <div className="flex items-center gap-2"><span className="w-3 h-3 rounded-full bg-cyan-500 border border-white"></span> Cable Station</div>
          <div className="flex items-center gap-2"><span className="w-3 h-3 rounded-full bg-orange-500 border border-white"></span> Transit Stop</div>
          <div className="flex items-center gap-2"><span className="w-4 h-1 bg-gray-300 border-b border-dashed"></span> Transit Route</div>
          
          <div className="border-t border-slate-700 my-1"></div>
          
          <div className="font-semibold text-slate-400">Pedestrian Traffic</div>
          <div className="flex items-center gap-2"><span className="w-4 h-1 bg-green-500"></span> Low Impact</div>
          <div className="flex items-center gap-2"><span className="w-4 h-1 bg-yellow-500"></span> Moderate Impact</div>
          <div className="flex items-center gap-2"><span className="w-4 h-1 bg-red-500"></span> High Impact</div>

          <div className="border-t border-slate-700 my-1"></div>
          <div className="font-semibold text-slate-400">Live Agents (per 100)</div>
          
          <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-yellow-400"></span> Resident ({params.counts?.residents || 0})
          </div>
          <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-orange-400"></span> Commuter (Transit) ({params.counts?.commutersBus || 0})
          </div>
          <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-cyan-400"></span> Commuter (Cable) ({params.counts?.commutersCable || 0})
          </div>
        </div>
      </div>
    </div>
  );
};
