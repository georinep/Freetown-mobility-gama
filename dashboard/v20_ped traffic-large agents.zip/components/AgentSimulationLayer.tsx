
import React, { useEffect, useRef } from 'react';
import { useMap } from 'react-leaflet';
import L from 'leaflet';
import { GeoJSONCollection, SimulationParams } from '../types';

interface AgentSimulationLayerProps {
  roads: GeoJSONCollection | null;
  transit: GeoJSONCollection | null;
  buildings: GeoJSONCollection | null;
  stops: GeoJSONCollection | null;
  cableStations: GeoJSONCollection | null;
  params: SimulationParams;
  simHour: number;
}

interface Agent {
  id: number;
  // Dynamic State
  path: [number, number][]; 
  currentPointIndex: number;
  progress: number;
  speed: number;
  
  // Static Props
  color: string;
  size: number;
  type: 'resident' | 'commuter_bus' | 'commuter_cable';
  
  // Locations
  originLocation?: [number, number]; // Morning Start
  destinationLocation?: [number, number]; // Office (Mid-day)
  eveningDestinationLocation?: [number, number]; // Evening End
  
  // Visual Spacing
  laneOffset: [number, number]; // Jitter to prevent stacking
  
  // State machine for Pedestrian
  state: 'moving' | 'resting_home' | 'working_office';
}

// Geometry Helpers
const distSq = (p1: [number, number], p2: [number, number]) => {
  return (p1[0]-p2[0])*(p1[0]-p2[0]) + (p1[1]-p2[1])*(p1[1]-p2[1]);
};

const distReal = (p1: [number, number], p2: [number, number]) => {
  return Math.sqrt(distSq(p1, p2));
};

const projectPointOnSegment = (p: [number, number], v: [number, number], w: [number, number]): [number, number] => {
  const l2 = distSq(v, w);
  if (l2 === 0) return v;
  let t = ((p[0] - v[0]) * (w[0] - v[0]) + (p[1] - v[1]) * (w[1] - v[1])) / l2;
  t = Math.max(0, Math.min(1, t));
  return [v[0] + t * (w[0] - v[0]), v[1] + t * (w[1] - v[1])];
};

export const AgentSimulationLayer: React.FC<AgentSimulationLayerProps> = ({ 
  roads, 
  transit, 
  buildings,
  stops,
  cableStations,
  params,
  simHour
}) => {
  const map = useMap();
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const agentsRef = useRef<Agent[]>([]);
  const frameRef = useRef<number>(0);
  
  // Spatial Index for Roads
  const roadGrid = useRef<Map<string, [number, number][][]>>(new Map());
  const GRID_SIZE = 0.002; // Approx 200m grid cells

  // Helper: Flatten GeoJSON into paths
  const extractPaths = (data: GeoJSONCollection | null): [number, number][][] => {
    if (!data || !data.features) return [];
    const paths: [number, number][][] = [];
    data.features.forEach(f => {
      const geometry = f.geometry;
      if (!geometry) return;
      if (geometry.type === 'LineString') {
        paths.push(geometry.coordinates.map((c: any) => [c[1], c[0]]));
      } else if (geometry.type === 'MultiLineString') {
        geometry.coordinates.forEach((line: any) => {
          paths.push(line.map((c: any) => [c[1], c[0]]));
        });
      }
    });
    return paths;
  };

  const getPointsByNature = (data: GeoJSONCollection | null, natureCheck: (n: string) => boolean): [number, number][] => {
     if (!data || !data.features) return [];
     return data.features
        .filter(f => {
           const nature = f.properties?.NATURE || '';
           return natureCheck(nature);
        })
        .flatMap((f): [number, number][] => {
           if (f.geometry.type === 'Polygon') return [[f.geometry.coordinates[0][0][1], f.geometry.coordinates[0][0][0]]];
           if (f.geometry.type === 'MultiPolygon') return [[f.geometry.coordinates[0][0][0][1], f.geometry.coordinates[0][0][0][0]]];
           return [];
        });
  };

  const extractPoints = (data: GeoJSONCollection | null): [number, number][] => {
    if (!data || !data.features) return [];
    return data.features.map((f): [number, number] => {
      if(f.geometry.type === 'Point') return [f.geometry.coordinates[1], f.geometry.coordinates[0]];
      return [0,0];
    }).filter(p => p[0] !== 0) as [number, number][];
  };

  // Find nearest single point
  const findClosest = (origin: [number, number], targets: [number, number][]) => {
      let closest = targets[0];
      let minDst = Infinity;
      for(let t of targets) {
          const d = distSq(origin, t);
          if (d < minDst) {
              minDst = d;
              closest = t;
          }
      }
      return closest;
  };

  // Get a random point from the top K closest (to allow "near" but distributed)
  const findNearbyRandom = (origin: [number, number], targets: [number, number][], topK: number = 20) => {
      // Sort all targets by distance (expensive for large sets, but acceptable for init)
      // Optimization: Just shuffle a subset or mapped array
      const withDist = targets.map(t => ({ point: t, d: distSq(origin, t) }));
      withDist.sort((a, b) => a.d - b.d);
      
      const slice = withDist.slice(0, Math.min(topK, withDist.length));
      const choice = slice[Math.floor(Math.random() * slice.length)];
      return choice.point;
  };

  // Build Spatial Grid for Roads
  useEffect(() => {
    roadGrid.current.clear();
    const paths = extractPaths(roads);
    
    paths.forEach(path => {
      // Break polyline into segments
      for(let i = 0; i < path.length - 1; i++) {
        const p1 = path[i];
        const p2 = path[i+1];
        
        // Determine grid cells this segment touches
        const minLat = Math.min(p1[0], p2[0]);
        const maxLat = Math.max(p1[0], p2[0]);
        const minLng = Math.min(p1[1], p2[1]);
        const maxLng = Math.max(p1[1], p2[1]);

        const startLatIdx = Math.floor(minLat / GRID_SIZE);
        const endLatIdx = Math.floor(maxLat / GRID_SIZE);
        const startLngIdx = Math.floor(minLng / GRID_SIZE);
        const endLngIdx = Math.floor(maxLng / GRID_SIZE);

        for(let r = startLatIdx; r <= endLatIdx; r++) {
          for(let c = startLngIdx; c <= endLngIdx; c++) {
            const key = `${r},${c}`;
            if(!roadGrid.current.has(key)) roadGrid.current.set(key, []);
            roadGrid.current.get(key)?.push([p1, p2]);
          }
        }
      }
    });
  }, [roads]);

  // Snap function with lane offset calculation
  const snapToRoad = (pos: [number, number], laneOffset: [number, number]): [number, number] => {
    const latIdx = Math.floor(pos[0] / GRID_SIZE);
    const lngIdx = Math.floor(pos[1] / GRID_SIZE);
    const key = `${latIdx},${lngIdx}`;
    
    const segments = roadGrid.current.get(key);
    // Apply offset even if not snapped if no road found (walking off-road)
    if (!segments || segments.length === 0) return [pos[0] + laneOffset[0], pos[1] + laneOffset[1]];

    let bestPoint = pos;
    let minDst = Infinity;

    // Check all nearby segments
    for (const seg of segments) {
      const proj = projectPointOnSegment(pos, seg[0], seg[1]);
      const d = distSq(pos, proj);
      if (d < minDst) {
        minDst = d;
        bestPoint = proj;
      }
    }

    if (minDst > 0.0000005) return [pos[0] + laneOffset[0], pos[1] + laneOffset[1]]; 

    // Apply the visual offset to the snapped point so agents don't walk in single file
    return [bestPoint[0] + laneOffset[0], bestPoint[1] + laneOffset[1]];
  };

  // Initialize Agents
  useEffect(() => {
    const residentialPoints = getPointsByNature(buildings, (n) => n === 'R' || n === 'Residential');
    const officePoints = getPointsByNature(buildings, (n) => n === 'Office' || n === 'office');
    const stopPoints = extractPoints(stops);
    const cablePoints = extractPoints(cableStations);

    const newAgents: Agent[] = [];
    const counts = params.counts || { residents: 0, commutersBus: 0, commutersCable: 0 };

    // Constant target speed in degrees per frame (Controls global speed)
    const GLOBAL_SPEED_FACTOR = 0.000001; 

    // Helper to get random distributed office
    const getRandomOffice = () => officePoints[Math.floor(Math.random() * officePoints.length)];

    // 1. Residents (Yellow)
    // Morning: Home -> Random Office (Equal Distribution)
    // Evening: Office -> Home
    if (residentialPoints.length > 0 && officePoints.length > 0) {
        for(let i=0; i<counts.residents; i++) {
            const home = residentialPoints[Math.floor(Math.random() * residentialPoints.length)];
            const office = getRandomOffice(); // Equally distributed destination
            
            // Calculate distance to normalize speed
            const tripDist = distReal(home, office);
            const normalizedSpeed = tripDist > 0 ? GLOBAL_SPEED_FACTOR / tripDist : 0;

            // Random jitter for visual spacing (approx +/- 5-10 meters)
            const jitterLat = (Math.random() - 0.5) * 0.00012;
            const jitterLng = (Math.random() - 0.5) * 0.00012;

            newAgents.push({
                id: i + 20000,
                path: [], 
                currentPointIndex: 0,
                // Evenly distribute progress to create a flow "one after the other"
                progress: (i / counts.residents), 
                speed: normalizedSpeed,
                color: '#facc15', // Yellow
                size: 2.2,
                type: 'resident',
                originLocation: home,
                destinationLocation: office,
                eveningDestinationLocation: home, // Return to home
                laneOffset: [jitterLat, jitterLng],
                state: 'resting_home'
            });
        }
    }

    // 2. Bus Commuters (Orange)
    // Morning: Stop -> Nearby Office (Distributed among nearby)
    // Evening: Office -> Nearest Stop
    if (stopPoints.length > 0 && officePoints.length > 0) {
         for(let i=0; i<counts.commutersBus; i++) {
             const start = stopPoints[Math.floor(Math.random() * stopPoints.length)];
             // Find office NEAR the stop, but distribute among top 20 nearest to avoid clustering
             const end = findNearbyRandom(start, officePoints, 20);
             
             // Evening return: Nearest stop to that office
             const eveningEnd = findClosest(end, stopPoints);

             const tripDist = distReal(start, end);
             const normalizedSpeed = tripDist > 0 ? GLOBAL_SPEED_FACTOR / tripDist : 0;

             const jitterLat = (Math.random() - 0.5) * 0.00012;
             const jitterLng = (Math.random() - 0.5) * 0.00012;
             
             newAgents.push({
                id: i + 30000,
                path: [],
                currentPointIndex: 0,
                progress: (i / counts.commutersBus), // Even spacing
                speed: normalizedSpeed,
                color: '#f97316', // Orange
                size: 2.2,
                type: 'commuter_bus',
                originLocation: start,
                destinationLocation: end,
                eveningDestinationLocation: eveningEnd,
                laneOffset: [jitterLat, jitterLng],
                state: 'moving'
             });
         }
    }

    // 3. Cable Commuters (Cyan) 
    // Morning: Station -> Random Office (Equal Distribution in project area)
    // Evening: Office -> Nearest Cable Station
    if (cablePoints.length > 0 && officePoints.length > 0) {
        for(let i=0; i<counts.commutersCable; i++) {
             const start = cablePoints[Math.floor(Math.random() * cablePoints.length)];
             const end = getRandomOffice(); // Equal distribution
             
             // Evening return: Nearest Cable Station
             const eveningEnd = findClosest(end, cablePoints);
             
             const tripDist = distReal(start, end);
             const normalizedSpeed = tripDist > 0 ? GLOBAL_SPEED_FACTOR / tripDist : 0;

             const jitterLat = (Math.random() - 0.5) * 0.00012;
             const jitterLng = (Math.random() - 0.5) * 0.00012;
             
             newAgents.push({
                id: i + 40000,
                path: [],
                currentPointIndex: 0,
                progress: (i / counts.commutersCable), // Even spacing
                speed: normalizedSpeed,
                color: '#06b6d4', // Cyan
                size: 2.2,
                type: 'commuter_cable',
                originLocation: start, 
                destinationLocation: end,
                eveningDestinationLocation: eveningEnd,
                laneOffset: [jitterLat, jitterLng],
                state: 'moving'
             });
        }
    }

    agentsRef.current = newAgents;
  }, [
      buildings, stops, cableStations, 
      params.counts?.residents,
      params.counts?.commutersBus,
      params.counts?.commutersCable,
      params.counts?.total
  ]);

  // Canvas Lifecycle
  useEffect(() => {
    const canvas = document.createElement('canvas');
    canvas.style.position = 'absolute';
    canvas.style.top = '0';
    canvas.style.left = '0';
    canvas.style.pointerEvents = 'none';
    canvas.style.zIndex = '600'; 
    canvas.style.width = '100%';
    canvas.style.height = '100%';
    const container = map.getContainer();
    container.appendChild(canvas);
    canvasRef.current = canvas;

    const resize = () => {
      const size = map.getSize();
      canvas.width = size.x;
      canvas.height = size.y;
    };
    
    const hide = () => { canvas.style.opacity = '0'; };
    const show = () => { resize(); canvas.style.opacity = '1'; };

    map.on('resize', resize);
    map.on('zoomstart', hide);
    map.on('zoomend', show);
    resize();

    return () => {
      map.off('resize', resize);
      map.off('zoomstart', hide);
      map.off('zoomend', show);
      if (canvas.parentNode) canvas.parentNode.removeChild(canvas);
      if (frameRef.current) cancelAnimationFrame(frameRef.current);
    };
  }, [map]);

  // Animation Loop with Time Logic
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const agents = agentsRef.current;
      const bounds = map.getBounds();

      // DETERMINE GLOBAL BEHAVIOR BASED ON DYNAMIC TIME RANGES
      const tr = params.timeRanges;
      
      const isMorningPeak = simHour >= tr.morningStart && simHour < tr.morningEnd;
      const isOffPeakWork = simHour >= tr.offpeakStart && simHour < tr.offpeakEnd;
      const isEveningPeak = simHour >= tr.eveningStart && simHour < tr.eveningEnd;
      
      const drawAgent = (agent: Agent) => {
         let lat = 0, lng = 0;
         let shouldDraw = true;

         // --- MOVEMENT LOGIC ---
         
         let start: [number, number] | undefined;
         let end: [number, number] | undefined;
         
         if (isMorningPeak) {
             start = agent.originLocation;
             end = agent.destinationLocation;
         } else if (isEveningPeak) {
             start = agent.destinationLocation;
             end = agent.eveningDestinationLocation; // Use specific evening return point
         }
         
         if (isMorningPeak || isEveningPeak) {
             // Moving Logic
             if (start && end) {
                 agent.progress += agent.speed;
                 if (agent.progress > 1) {
                     agent.progress = 0; 
                 }
                 
                 // Linear Interpolation
                 const linLat = start[0] + (end[0] - start[0]) * agent.progress;
                 const linLng = start[1] + (end[1] - start[1]) * agent.progress;

                 // Snap to closest road segment to simulate "following path"
                 // Pass laneOffset to keep them slightly separated
                 const snapped = snapToRoad([linLat, linLng], agent.laneOffset);
                 lat = snapped[0];
                 lng = snapped[1];

             } else {
                 shouldDraw = false;
             }
         } else if (isOffPeakWork) {
             // Static at Office/Destination
             if (agent.destinationLocation) {
                 [lat, lng] = agent.destinationLocation;
             } else shouldDraw = false;
         } else {
             // Night/Early Morning - Static at Home/Origin
             if (agent.originLocation) {
                 [lat, lng] = agent.originLocation;
             } else shouldDraw = false;
         }

         if (!shouldDraw) return;
         if (!bounds.contains([lat, lng])) return;

         const point = map.latLngToContainerPoint([lat, lng]);
         // Bounds check canvas
         if (point.x < -10 || point.y < -10 || point.x > canvas.width + 10 || point.y > canvas.height + 10) return;

         ctx.fillStyle = agent.color;
         ctx.beginPath();
         ctx.arc(point.x, point.y, agent.size, 0, Math.PI * 2);
         ctx.fill();
      };

      agents.forEach(drawAgent);
      frameRef.current = requestAnimationFrame(animate);
    };

    frameRef.current = requestAnimationFrame(animate);
    return () => {
      if (frameRef.current) cancelAnimationFrame(frameRef.current);
    };
  }, [map, simHour, params.timeRanges]);

  return null;
};
