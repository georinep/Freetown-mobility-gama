import React from 'react';
import { Play, Activity, Maximize2 } from 'lucide-react';

export const ModelPlaceholder: React.FC = () => {
  return (
    <div className="w-full h-full bg-black relative overflow-hidden group">
      {/* Simulation Grid Background Effect */}
      <div className="absolute inset-0 opacity-20" 
           style={{ 
             backgroundImage: 'radial-gradient(#22c55e 1px, transparent 1px)', 
             backgroundSize: '20px 20px' 
           }}>
      </div>
      
      {/* Animated Mock Agents */}
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-3/4 h-3/4 border border-green-900/50 rounded-lg flex items-center justify-center">
         <div className="text-center">
            <div className="relative inline-flex mb-4">
              <span className="absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-20 animate-ping"></span>
              <div className="w-16 h-16 bg-slate-900 rounded-full border-2 border-green-500 flex items-center justify-center shadow-[0_0_15px_rgba(34,197,94,0.5)]">
                 <Activity className="text-green-500 w-8 h-8" />
              </div>
            </div>
            <h3 className="text-green-500 font-mono text-lg font-bold tracking-widest uppercase">Simulation Active</h3>
            <p className="text-slate-500 text-xs mt-2 font-mono">Rendering GAMA Agent Stream...</p>
         </div>
         
         {/* Decorative Scanline */}
         <div className="absolute inset-0 bg-gradient-to-b from-transparent via-green-500/5 to-transparent h-4 w-full animate-scan"></div>
      </div>

      {/* Floating HUD elements */}
      <div className="absolute top-4 right-4 bg-black/50 backdrop-blur border border-green-900 px-3 py-1 rounded text-[10px] font-mono text-green-400">
        FPS: 59.9
      </div>
      
      <div className="absolute bottom-6 left-6 right-6 flex justify-between items-center">
         <div className="flex gap-2">
            <button className="p-2 bg-green-600 hover:bg-green-500 text-black rounded shadow-lg transition-colors">
              <Play className="w-4 h-4 fill-current" />
            </button>
            <div className="h-8 w-64 bg-slate-900/80 border border-slate-700 rounded overflow-hidden flex items-center px-2">
               <div className="h-1 bg-green-600 w-2/3 shadow-[0_0_8px_rgba(34,197,94,0.8)]"></div>
            </div>
         </div>
         <button className="text-slate-400 hover:text-white transition-colors">
            <Maximize2 className="w-5 h-5" />
         </button>
      </div>
      
      <style>{`
        @keyframes scan {
          0% { top: 0%; opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 1; }
          100% { top: 100%; opacity: 0; }
        }
        .animate-scan {
          animation: scan 3s linear infinite;
        }
      `}</style>
    </div>
  );
};