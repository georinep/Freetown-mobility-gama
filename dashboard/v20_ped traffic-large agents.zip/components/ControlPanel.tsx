
import React from 'react';
import { Settings, Layers, Bus, TrendingUp, Clock } from 'lucide-react';
import { SimulationParams } from '../types';
import { Slider } from './ui/Slider';

interface ControlPanelProps {
  params: SimulationParams;
  setParams: React.Dispatch<React.SetStateAction<SimulationParams>>;
  layerVisibility: Record<string, boolean>;
  toggleLayer: (layer: string) => void;
}

export const ControlPanel: React.FC<ControlPanelProps> = ({ 
  params, 
  setParams,
  layerVisibility,
  toggleLayer
}) => {
  
  const updateParam = (key: keyof SimulationParams, value: any) => {
    setParams(prev => ({ ...prev, [key]: value }));
  };

  const updatePedestrian = (key: keyof SimulationParams['pedestrian'], value: any) => {
    setParams(prev => ({
      ...prev,
      pedestrian: {
        ...prev.pedestrian,
        [key]: value
      }
    }));
  };

  return (
    <div className="w-80 bg-slate-900 border-r border-slate-800 flex flex-col h-full overflow-y-auto custom-scrollbar shadow-xl z-20">
      <div className="p-6 border-b border-slate-800">
        <h1 className="text-xl font-bold text-white flex items-center gap-2">
          <Settings className="w-5 h-5 text-blue-500" />
          Simulation Control
        </h1>
        <p className="text-xs text-slate-500 mt-1">Freetown Pedestrian Mobility Analysis</p>
      </div>

      <div className="p-6 space-y-8">
        {/* Scenario Selection */}
        <div>
          <h2 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
            <Layers className="w-4 h-4 text-purple-400" /> Scenario
          </h2>
          <div className="grid grid-cols-2 gap-2 bg-slate-800 p-1 rounded-lg">
            {(['Baseline', 'Transit Expansion'] as const).map((s) => (
              <button
                key={s}
                onClick={() => updateParam('scenario', s)}
                className={`py-2 px-3 text-xs font-medium rounded-md transition-all ${
                  params.scenario === s 
                    ? 'bg-blue-600 text-white shadow-lg' 
                    : 'text-slate-400 hover:text-white hover:bg-slate-700'
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Time Settings */}
        <div>
           <h2 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
            <Clock className="w-4 h-4 text-orange-400" /> Time Settings
          </h2>
          
          <div className="space-y-3">
            <div className="flex flex-col gap-1">
               <label className="text-xs text-slate-400">Time Period (Jumps to Start)</label>
               <select 
                value={params.timeOfDay}
                onChange={(e) => updateParam('timeOfDay', e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 text-slate-200 text-xs rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2"
              >
                <option value="Morning">Morning Peak ({params.timeRanges.morningStart}:00 - {params.timeRanges.morningEnd}:00)</option>
                <option value="Off-peak">Off-peak ({params.timeRanges.offpeakStart}:00 - {params.timeRanges.offpeakEnd}:00)</option>
                <option value="Evening">Evening Peak ({params.timeRanges.eveningStart}:00 - {params.timeRanges.eveningEnd}:00)</option>
              </select>
            </div>
          </div>
        </div>

        <hr className="border-slate-800" />

        {/* Transit Expansion Controls */}
        <div>
          {params.scenario === 'Transit Expansion' && (
            <>
              <h2 className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-purple-400" /> Densification
              </h2>
              <Slider 
                label="Increase Residents" 
                value={params.pedestrian.densificationResidentPct} 
                min={0} max={100} unit="%"
                onChange={(v) => updatePedestrian('densificationResidentPct', v)} 
                colorClass="accent-yellow-500"
              />
              <Slider 
                label="Increase Commuters" 
                value={params.pedestrian.densificationCommuterPct} 
                min={0} max={100} unit="%"
                onChange={(v) => updatePedestrian('densificationCommuterPct', v)} 
                colorClass="accent-orange-500"
              />
            
              <h2 className="text-sm font-semibold text-white mb-4 flex items-center gap-2 mt-6">
                <Bus className="w-4 h-4 text-cyan-400" /> Transit Configuration
              </h2>
              <Slider 
                label="Cable Car Preference" 
                value={params.cableCarTransitShare} 
                min={0} max={100} unit="%" 
                onChange={(v) => updateParam('cableCarTransitShare', v)} 
                colorClass="accent-cyan-500"
              />
            </>
          )}
        </div>
        
        <hr className="border-slate-800" />

        {/* Layers Toggles */}
        <div>
           <h2 className="text-sm font-semibold text-white mb-3">Map Layers</h2>
           <div className="space-y-2">
             {Object.entries(layerVisibility).map(([key, isVisible]) => (
               <label key={key} className="flex items-center space-x-2 cursor-pointer group">
                 <input 
                   type="checkbox" 
                   checked={isVisible}
                   onChange={() => toggleLayer(key)}
                   className="form-checkbox h-4 w-4 text-blue-600 rounded bg-slate-800 border-slate-600 focus:ring-blue-500 focus:ring-offset-slate-900"
                 />
                 <span className="text-sm text-slate-400 group-hover:text-slate-200 transition-colors capitalize">
                   {key.replace(/([A-Z])/g, ' $1').trim()}
                 </span>
               </label>
             ))}
           </div>
        </div>

      </div>
    </div>
  );
};
