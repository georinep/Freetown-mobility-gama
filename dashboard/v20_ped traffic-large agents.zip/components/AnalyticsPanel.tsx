
import React, { useMemo } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, 
  PieChart, Pie, Cell, AreaChart, Area
} from 'recharts';
import { SimulationParams } from '../types';

interface AnalyticsPanelProps {
  params: SimulationParams;
  destructionCoeff: number;
  travelTimeDelta: number;
}

export const AnalyticsPanel: React.FC<AnalyticsPanelProps> = ({ params, destructionCoeff, travelTimeDelta }) => {
  
  // Modal Split Data
  const mobilityData = useMemo(() => {
     // Based on commuter split
     const cable = params.cableCarTransitShare;
     const transit = 100 - cable; 
     
     return [
       { name: 'Commuters (Transit)', value: transit, color: '#f97316' },
       { name: 'Cable Car', value: cable, color: '#06b6d4' },
     ];
  }, [params]);

  // Accurate Travel Time Data
  const travelTimeData = useMemo(() => {
    // Existing (Baseline) vs Transit Expansion
    const isExpansion = params.scenario === 'Transit Expansion';
    
    // Baseline times (minutes)
    const baseShort = 18;
    const baseMedium = 42;
    const baseLong = 75;

    // In Baseline scenario, the "Transit Scenario" bar should mirror the Baseline exactly
    if (!isExpansion) {
      return [
        { name: 'Short (<5km)', baseline: baseShort, scenario: baseShort },
        { name: 'Medium (5-15km)', baseline: baseMedium, scenario: baseMedium },
        { name: 'Long (>15km)', baseline: baseLong, scenario: baseLong },
      ];
    }

    // Expansion improvements
    // Base improvement: 10% (0.9 multiplier)
    // Cable car impact: reduces travel time significantly as share increases
    // E.g. 50% share adds another ~25% reduction
    const cableImpact = (params.cableCarTransitShare / 100) * 0.5; 
    const improvementMultiplier = Math.max(0.4, 0.9 - cableImpact);

    // Congestion calculated from agent load AND explicit densification sliders
    const loadFactor = params.counts ? (params.counts.total / 3000) : 0.5;
    
    const denRes = params.pedestrian.densificationResidentPct || 0;
    const denCom = params.pedestrian.densificationCommuterPct || 0;
    const densificationImpact = (denRes + denCom) / 200; // 0 to 1 scale roughly

    // Penalty increases with load and specifically with densification sliders
    // 0.25 weight for densification ensures "slight" but visible impact
    const congestionPenalty = 1 + (loadFactor * 0.15) + (densificationImpact * 0.25); 
    
    const finalMultiplier = improvementMultiplier * congestionPenalty;

    return [
      { name: 'Short (<5km)', baseline: baseShort, scenario: baseShort * finalMultiplier },
      { name: 'Medium (5-15km)', baseline: baseMedium, scenario: baseMedium * finalMultiplier },
      { name: 'Long (>15km)', baseline: baseLong, scenario: baseLong * (finalMultiplier - 0.05) }, // Long trips benefit slightly more
    ];
  }, [params]);

  const hourlyVolume = useMemo(() => {
    const data = [];
    
    // Road Destruction Analysis Logic:
    // Volume is driven by "Road Agents" (Residents + Bus Commuters). 
    // Cable Car commuters are off-road, providing relief.
    const roadAgents = (params.counts?.residents || 0) + (params.counts?.commutersBus || 0);

    for (let i = 0; i <= 23; i++) {
      let volume = 0;
      // Generate curve based on timeRanges
      const tr = params.timeRanges;
      
      const isMorning = i >= tr.morningStart && i < tr.morningEnd;
      const isEvening = i >= tr.eveningStart && i < tr.eveningEnd;
      const isOffPeak = i >= tr.offpeakStart && i < tr.offpeakEnd;

      if (isMorning || isEvening) {
        // Peak hours: Full load of road agents
        volume = roadAgents;
      } else if (isOffPeak) {
        // Off-peak: Reduced activity (e.g. 40%)
        volume = roadAgents * 0.4; 
      } else {
        // Night: minimal activity
        volume = roadAgents * 0.1; 
      }

      // Add noise for organic look
      volume = volume * (0.95 + Math.random() * 0.1);
      
      data.push({
        hour: `${i}:00`,
        volume: Math.round(volume)
      });
    }
    return data;
  }, [params]);

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-slate-800 border border-slate-700 p-2 rounded shadow-lg text-xs">
          <p className="font-bold text-slate-200">{label}</p>
          {payload.map((entry: any, index: number) => (
             <p key={index} style={{ color: entry.color }}>
               {entry.name}: {typeof entry.value === 'number' ? entry.value.toFixed(1) : entry.value}
             </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="h-64 bg-slate-900 border-t border-slate-800 grid grid-cols-1 md:grid-cols-3 gap-0 divide-x divide-slate-800">
      
      {/* Chart 1: Modal Split */}
      <div className="p-4 flex flex-col">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Modal Split Forecast</h3>
        <div className="flex-1 min-h-0 flex items-center justify-center">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={mobilityData}
                cx="50%"
                cy="45%"
                innerRadius={40}
                outerRadius={55}
                paddingAngle={5}
                dataKey="value"
              >
                {mobilityData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} stroke="none" />
                ))}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
              <Legend 
                verticalAlign="bottom" 
                align="center" 
                layout="horizontal" 
                iconSize={8} 
                wrapperStyle={{ fontSize: '12px', bottom: 0, width: '100%', marginBottom: '0px' }} 
              />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Chart 2: Travel Time & Metrics */}
      <div className="p-4 flex flex-col relative">
        <div className="flex justify-between items-start mb-2">
           <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Avg Travel Time</h3>
           {/* Embedded Metrics */}
           <div className="flex flex-col items-end gap-1">
             <div className="flex items-center gap-2 text-[10px]">
               <span className="text-slate-500 font-bold uppercase">Delta</span>
               <span className={`${travelTimeDelta < 0 ? 'text-green-400' : 'text-slate-300'} font-mono`}>{travelTimeDelta.toFixed(1)}%</span>
             </div>
             <div className="flex items-center gap-2 text-[10px]">
               <span className="text-slate-500 font-bold uppercase">Destr. Coeff</span>
               <span className={`${destructionCoeff > 1.2 ? 'text-red-400' : 'text-green-400'} font-mono`}>{destructionCoeff.toFixed(2)}</span>
             </div>
           </div>
        </div>
        
        <div className="flex-1 min-h-0">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={travelTimeData} barGap={2} barCategoryGap="20%">
              <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 9, fill: '#94a3b8'}} />
              <YAxis hide />
              <Tooltip content={<CustomTooltip />} cursor={{fill: 'transparent'}} />
              <Legend verticalAlign="top" iconSize={8} wrapperStyle={{ fontSize: '10px' }} />
              <Bar dataKey="baseline" name="Baseline (min)" fill="#64748b" radius={[4, 4, 0, 0]} />
              <Bar dataKey="scenario" name="Expansion Scenario (min)" fill={params.scenario === 'Transit Expansion' ? "#22c55e" : "#3b82f6"} radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Chart 3: Hourly Traffic Volume */}
      <div className="p-4 flex flex-col">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Hourly Road Activity</h3>
        <div className="flex-1 min-h-0">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={hourlyVolume}>
              <defs>
                <linearGradient id="colorVolume" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#eab308" stopOpacity={0.8}/>
                  <stop offset="95%" stopColor="#eab308" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <XAxis dataKey="hour" axisLine={false} tickLine={false} tick={{fontSize: 9, fill: '#94a3b8'}} interval={3} />
              <YAxis hide />
              <Tooltip content={<CustomTooltip />} />
              <Area 
                type="monotone" 
                dataKey="volume" 
                name="Road Agents"
                stroke="#eab308" 
                fillOpacity={1} 
                fill="url(#colorVolume)" 
                animationDuration={500}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

    </div>
  );
};
