
import React, { useState, useEffect, useMemo } from 'react';
import { ControlPanel } from './components/ControlPanel';
import { DashboardMap } from './components/DashboardMap';
import { AnalyticsPanel } from './components/AnalyticsPanel';
import { DataSourcesPanel } from './components/DataSourcesPanel';
import { SimulationParams, UploadedFiles } from './types';
import { Map as MapIcon, Database, Clock } from 'lucide-react';

const App: React.FC = () => {
  // Global Simulation State
  const [params, setParams] = useState<SimulationParams>({
    cableCarTransitShare: 15,
    timeOfDay: 'Morning',
    scenario: 'Baseline',
    pedestrian: {
      baseResidentCount: 170, // Updated default
      baseCommuterCount: 1500, // Updated default
      densificationResidentPct: 0,
      densificationCommuterPct: 0,
    },
    timeRanges: {
        morningStart: 7,
        morningEnd: 10,
        offpeakStart: 10,
        offpeakEnd: 16,
        eveningStart: 16,
        eveningEnd: 19
    }
  });

  // Uploaded Data State
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFiles>({});

  // UI State
  const [activeTab, setActiveTab] = useState<'map' | 'data'>('map');
  const [layerVisibility, setLayerVisibility] = useState({
    buildings: true,
    roads: true,
    stops: true,
    cableStations: true,
    transitSegments: true,
    agents: true,
  });

  // Time Lapse State
  const [simHour, setSimHour] = useState(7);

  // Time Loop with Skipping Logic
  useEffect(() => {
    const timer = setInterval(() => {
      setSimHour(prev => {
        let next = prev + 1;
        
        let loopStart = params.timeRanges.morningStart;
        let loopEnd = params.timeRanges.morningEnd;

        // Determine loop boundaries based on selected time period
        if (params.timeOfDay === 'Morning') {
          loopStart = params.timeRanges.morningStart;
          loopEnd = params.timeRanges.morningEnd;
        } else if (params.timeOfDay === 'Off-peak') {
          loopStart = params.timeRanges.offpeakStart;
          loopEnd = params.timeRanges.offpeakEnd;
        } else if (params.timeOfDay === 'Evening') {
          loopStart = params.timeRanges.eveningStart;
          loopEnd = params.timeRanges.eveningEnd;
        }

        // Loop within the specific period
        if (next >= loopEnd) {
            return loopStart;
        }
        return next;
      });
    }, 8000); 
    return () => clearInterval(timer);
  }, [params.timeRanges, params.timeOfDay]);

  // Sync simulation hour when user changes Time Period manually (Jump to start of period)
  useEffect(() => {
    switch (params.timeOfDay) {
      case 'Morning': 
        setSimHour(params.timeRanges.morningStart); 
        break;
      case 'Off-peak': 
        setSimHour(params.timeRanges.offpeakStart); 
        break;
      case 'Evening': 
        setSimHour(params.timeRanges.eveningStart); 
        break;
    }
  }, [params.timeOfDay, params.timeRanges]);

  const toggleLayer = (layer: string) => {
    setLayerVisibility(prev => ({ ...prev, [layer]: !prev[layer as keyof typeof prev] }));
  };

  const handleFileUpload = (key: keyof UploadedFiles, file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const json = JSON.parse(e.target?.result as string);
        setUploadedFiles(prev => ({ ...prev, [key]: json }));
      } catch (err) {
        console.error("Failed to parse GeoJSON", err);
        alert("Invalid GeoJSON file");
      }
    };
    reader.readAsText(file);
  };

  // Derived Metrics & Counts
  const densificationRes = params.scenario === 'Transit Expansion' ? params.pedestrian.densificationResidentPct : 0;
  const densificationCom = params.scenario === 'Transit Expansion' ? params.pedestrian.densificationCommuterPct : 0;

  const residentCount = Math.floor(params.pedestrian.baseResidentCount * (1 + densificationRes/100));
  const totalCommuterCount = Math.floor(params.pedestrian.baseCommuterCount * (1 + densificationCom/100));
  
  // Calculate specific modal counts
  const cableSharePct = params.scenario === 'Transit Expansion' ? params.cableCarTransitShare : 0;
  const cableCount = Math.floor(totalCommuterCount * (cableSharePct/100));
  const busCount = totalCommuterCount - cableCount;
  const totalAgents = residentCount + totalCommuterCount;

  // Destruction Coeff Logic
  // Check if we are in off-peak hours
  const isOffPeak = simHour >= params.timeRanges.offpeakStart && simHour < params.timeRanges.offpeakEnd;
  
  // Baseline is ~1.0. Increases with volume, Decreases with Cable Car Share (Load Relief)
  const loadFactor = totalAgents / 2000; 
  const reliefFactor = cableSharePct / 200; // e.g. 50% share -> 0.25 relief
  
  // If offpeak, impact is negligible (green roads)
  const destructionCoeff = isOffPeak 
    ? 0.1 
    : 1.0 + loadFactor - reliefFactor;

  // Travel Time Delta: Improves (becomes negative) with expansion and cable car share
  const travelTimeDelta = params.scenario === 'Transit Expansion' 
    ? -1 * (10 + (params.cableCarTransitShare * 0.4)) // Base 10% + up to 20% more
    : 0;

  // Memoize the params with counts to prevent unstable references causing re-renders
  const paramsWithCounts = useMemo(() => ({
      ...params,
      counts: {
          residents: residentCount,
          commutersBus: busCount,
          commutersCable: cableCount,
          total: totalAgents
      }
  }), [params, residentCount, busCount, cableCount, totalAgents]);

  return (
    <div className="flex h-screen bg-slate-950 font-sans text-slate-100 overflow-hidden">
      
      {/* Left Sidebar */}
      <ControlPanel 
        params={paramsWithCounts} 
        setParams={setParams} 
        layerVisibility={layerVisibility}
        toggleLayer={toggleLayer}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col h-full relative">
        
        {/* Top Tab Bar */}
        <div className="h-12 bg-slate-900 border-b border-slate-800 flex items-center justify-between px-4">
          <div className="flex bg-slate-800 p-1 rounded-lg">
            <button
              onClick={() => setActiveTab('map')}
              className={`flex items-center gap-2 px-4 py-1.5 rounded-md text-xs font-medium transition-all ${
                activeTab === 'map' ? 'bg-slate-700 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <MapIcon className="w-3.5 h-3.5" /> Geospatial View
            </button>
            <button
              onClick={() => setActiveTab('data')}
              className={`flex items-center gap-2 px-4 py-1.5 rounded-md text-xs font-medium transition-all ${
                activeTab === 'data' ? 'bg-slate-700 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Database className="w-3.5 h-3.5" /> Data Sources
            </button>
          </div>
          
          <div className="flex items-center gap-6">
             {/* Time Lapse Display */}
             <div className="flex items-center gap-3 bg-slate-800/50 px-3 py-1.5 rounded-md border border-slate-700/50">
               <div className="flex flex-col items-end leading-none">
                 <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Simulation Time</span>
                 <span className="text-xs text-blue-400">Freetown CBD</span>
               </div>
               <div className="h-6 w-px bg-slate-700"></div>
               <div className="flex items-center gap-2">
                 <Clock className="w-4 h-4 text-slate-300" />
                 <span className="font-mono text-lg font-bold text-white tabular-nums">
                   {simHour.toString().padStart(2, '0')}:00
                 </span>
               </div>
             </div>
          </div>
        </div>

        {/* Viewport */}
        <div className="flex-1 relative bg-black min-h-0">
          {activeTab === 'map' ? (
            <div className="w-full h-full relative">
              <DashboardMap 
                params={paramsWithCounts} 
                layerVisibility={layerVisibility} 
                uploadedFiles={uploadedFiles}
                simHour={simHour}
              />
            </div>
          ) : (
            <DataSourcesPanel 
              uploadedFiles={uploadedFiles} 
              onFileUpload={handleFileUpload} 
              params={paramsWithCounts}
              setParams={setParams}
            />
          )}
        </div>

        {/* Bottom Analytics */}
        <AnalyticsPanel 
            params={paramsWithCounts} 
            destructionCoeff={destructionCoeff}
            travelTimeDelta={travelTimeDelta}
        />

      </div>
    </div>
  );
};

export default App;
