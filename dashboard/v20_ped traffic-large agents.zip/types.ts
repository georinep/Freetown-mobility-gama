
export interface PedestrianParams {
  baseResidentCount: number;
  baseCommuterCount: number;
  densificationResidentPct: number; // Slider for increase
  densificationCommuterPct: number; // Slider for increase
}

export interface TimeRanges {
  morningStart: number;
  morningEnd: number;
  offpeakStart: number;
  offpeakEnd: number;
  eveningStart: number;
  eveningEnd: number;
}

export interface CalculatedCounts {
  residents: number;
  commutersBus: number;
  commutersCable: number;
  total: number;
}

export interface SimulationParams {
  cableCarTransitShare: number; // Percentage
  timeOfDay: 'Morning' | 'Off-peak' | 'Evening';
  scenario: 'Baseline' | 'Transit Expansion';
  pedestrian: PedestrianParams;
  timeRanges: TimeRanges;
  counts?: CalculatedCounts; // Derived state passed down
}

export interface GeoJSONFeature {
  type: "Feature";
  properties: {
    NATURE?: string;
    stop_id?: string;
    stop_name?: string;
    [key: string]: any;
  };
  geometry: any;
}

export interface GeoJSONCollection {
  type: "FeatureCollection";
  features: GeoJSONFeature[];
}

export interface ChartData {
  name: string;
  value: number;
  fill?: string;
}

export interface TravelTimeData {
  category: string;
  baseline: number;
  scenario: number;
}

export interface UploadedFiles {
  buildings?: GeoJSONCollection | null;
  roads?: GeoJSONCollection | null;
  stops?: GeoJSONCollection | null;
  cableStations?: GeoJSONCollection | null;
  morning?: GeoJSONCollection | null;
  offpeak?: GeoJSONCollection | null;
  evening?: GeoJSONCollection | null;
  weekend?: GeoJSONCollection | null;
}
